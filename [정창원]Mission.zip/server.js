var fs = require('fs'),
	express = require('express'),
	bodyParser = require('body-parser'),
	db = require('./db_init.js'),
	app = express(),
	path = require('path');				//추가되었습니다.
	const imgKeyword = 'data:image/'	//추가되었습니다.
/*
	아래부터 작성된 코드 입니다.
*/
app.use(express.static(path.join(__dirname,'static')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));

app.get('/',(req,res)=>{
	res.render('index.html');
});

app.get('/api/fetchProblem',(req,res)=>{
	db.Problem.findAll({
		attributes : ['id', 'problem_text', 'type', 'choices'];
	}).then(result=>{
		const resultJson = [];
		for(let i = 0 ; i < result.length ; i ++){
			resultJson.push(result[i].dataValues);
		}
		res.json({"problems":resultJson});
	}).catch(e=>{
		console.log(`[ERROR][GET][/api/fetchProblem] on select prbloms : ${e}`);
	});
});

app.post('/api/submit',(req,res)=>{
	const resJson = {};
			resJson.results = [];
	const reqResult = JSON.parse(req.body.input);
	
	const tempMap = new Map();
	for(var i = 0 ; i < reqResult.length; i++){
		tempMap.set(reqResult[i].id,reqResult[i].answer);
	}//db.Problem과의 값을 쉽게 정리하기 위해 부득이하게 추가되었습니다. findAll 이후 쓸모없습니다.
	
	db.Problem.findAll({
		attributes : ["id","answer"]
	}).then	(result=>{
		for(let j = 0 ; j < result.length ; j++){
			const userResult = {id :result[j].dataValues.id,result : (tempMap.get(result[j].dataValues.id) == result[j].dataValues.answer) || (result[j].dataValues.answer.indexOf(imgKeyword) != -1) ? true : false,answer : tempMap.get(result[j].dataValues.id) }
			const temp = {id :result[j].dataValues.id,result : (tempMap.get(result[j].dataValues.id) == result[j].dataValues.answer) || (result[j].dataValues.answer.indexOf(imgKeyword) != -1) ? true : false,answer : result[j].dataValues.answer }
			resJson.results.push(temp);
			insertToDB(userResult);
		}
		res.json({"results":resJson.results});
		tempMap = null;
	}).catch(e=>{
		console.log(`[ERROR][POST][/api/submit] on select prbloms : ${e}`);
	});
});

const insertToDB = (values)=>{
	db.Result.create({
		problem_id :values.id,
		answer : values.answer,
		result:values.result
	}).then(result=>{
		console.log(`[INFO] insert success`);
	}).catch(err=>{
		console.log(`[ERROR] insert failed : ${err}`);
	});
}//insert clients Result. it dont need to call back.

/* 
	작성된 코드 끝
	추가 필요 작업 : 라우터 모듈화, DB관련 기능 모듈화
*/
var server = app.listen(3000, function() {
		console.log('Server started');
	});
